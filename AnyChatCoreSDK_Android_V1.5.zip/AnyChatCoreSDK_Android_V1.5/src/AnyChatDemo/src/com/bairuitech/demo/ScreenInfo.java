package com.bairuitech.demo;

public class ScreenInfo {
	public static int WIDTH;
	public static int HEIGHT;
}
